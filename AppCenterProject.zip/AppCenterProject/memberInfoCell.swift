//
//  memberInfo.swift
//  AppCenterProject
//
//  Created by 김민정 on 2021/08/08.
//

import Foundation
import UIKit
class memberInfoCell:UIView{
    //네임카드에 들어갈 이름,전공,학번,방번호,사생번호의 정보를 받는 레이블입니다.
    @IBOutlet var nameLabel:UILabel?
    @IBOutlet var majorLabel:UILabel?
    @IBOutlet var numberLabel:UILabel?
    @IBOutlet var roomInfoLabel:UILabel?
    @IBOutlet var roomNumberLabel:UILabel?

    
}
