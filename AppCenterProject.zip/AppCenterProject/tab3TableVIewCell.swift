//
//  tab3TableVIewCell.swift
//  AppCenterProject
//
//  Created by 김민정 on 2021/08/11.
//

import Foundation
import UIKit
// 탭3의 테이블뷰셀을 컨트롤 하는 파일
class tab3TableViewCell:UITableViewCell {
    
    @IBOutlet var dateCellLabel:UILabel?
    @IBOutlet var pointNameCellLabel:UILabel?
    @IBOutlet var pointCellLabel:UILabel?
    @IBOutlet var pointSumCellLabel:UILabel?
    
    
    
    
    
}
