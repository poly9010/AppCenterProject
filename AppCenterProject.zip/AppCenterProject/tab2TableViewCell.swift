//
//  tab2TableViewCell.swift
//  AppCenterProject
//
//  Created by 김민정 on 2021/08/23.
//

import Foundation
import UIKit
class tab2TableViewCell:UITableViewCell{
    @IBOutlet weak var month:UIView?
    @IBOutlet weak var date:UILabel?
    @IBOutlet weak var amount:UILabel?
    @IBOutlet weak var fee:UILabel?
}
